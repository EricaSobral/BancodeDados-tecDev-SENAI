--DQL
SELECT * FROM Empresa;