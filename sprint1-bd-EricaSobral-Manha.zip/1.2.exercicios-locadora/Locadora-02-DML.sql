--DML 
INSERT INTO Empresa (Nome, Endereco)
VALUES ('Aluga Carro', 'Alameda Bar�o de Limeira, 333');